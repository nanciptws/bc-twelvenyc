import 'focus-within-polyfill';

import './global/jquery-migrate';
import './common/select-option-plugin';
import PageManager from './page-manager';
import quickSearch from './global/quick-search';
import currencySelector from './global/currency-selector';
import languageSelector from './global/language-selector';
import mobileMenuToggle from './global/mobile-menu-toggle';
import menu from './global/menu';
import foundation from './global/foundation';
import quickView from './global/quick-view';
import cartPreview from './global/cart-preview';
import carousel from './common/carousel';
import svgInjector from './global/svg-injector';
import twelveHeader from './global/twelve-header';
import twelveFooter from './global/twelve-footer';
import welcomeIntro from './global/welcome-intro';
import wishlistMobileSheet from './global/wishlist-mobile-sheet';

export default class Global extends PageManager {
    onReady() {
        const { cartId, secureBaseUrl } = this.context;
        cartPreview(secureBaseUrl, cartId);
        quickSearch();
        currencySelector(cartId);
        languageSelector();
        foundation($(document));
        quickView(this.context);
        carousel(this.context);
        menu();
        mobileMenuToggle();
        twelveHeader();
        twelveFooter();
        welcomeIntro();
        wishlistMobileSheet();
        svgInjector();
    }
}
